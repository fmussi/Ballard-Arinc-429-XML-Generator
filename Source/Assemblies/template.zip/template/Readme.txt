1) copy .xsd file in this folder
2) open the Developer Command Prompt for VS <year>
3) run the xsd <schema .xsd file name> /classes
4) (optional) rename the .sln file
5) open the .sln file
6) edit the AssemblyInfo.cs and edit infos
7) Rename the project
8) right click the project and set default namespace to project name
9) Build the solution and locate the dll under /bin/Debug